package com.example.lab_3amrh;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private enum Operator{none, add, multiply, divide, minus}
    private double data1 = 0, data2 = 0;
    private Operator optr = Operator.none;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void button00Click(View view){
        TextView eText = (TextView)findViewById(R.id.ResultEdit);
        eText.setText(eText.getText() + "0");
    }
    public void button01Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "1");
    }
    public void button02Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "2");
    }
    public void button03Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "3");
    }
    public void button04Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "4");

    }
    public void button05Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "5");
    }
    public void button06Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "6");
    }
    public void button07Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "7");
    }
    public void button08Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "8");
    }
    public void button09Click(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + "9");
    }
    public void buttondotClick(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText(etext.getText() + ".");
    }
    public void buttoncClick(View view){
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        etext.setText("");
    }
    public void buttonminusClick(View view){
        optr = Operator.minus;
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        data1 = Double.parseDouble(etext.getText().toString());
        etext.setText("");
    }
    public void buttonstarClick(View view){
        optr = Operator.multiply;
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        data1 = Double.parseDouble(etext.getText().toString());
        etext.setText("");
    }
    public void buttonplusClick(View view){
        optr = Operator.add;
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        data1 = Double.parseDouble(etext.getText().toString());
        etext.setText("");
    }
    public void buttondivClick(View view){
        optr = Operator.divide;
        TextView etext = (TextView)findViewById(R.id.ResultEdit);
        data1 = Double.parseDouble(etext.getText().toString());
        etext.setText("");
    }
    public void buttoneqClick(View view){
        if(optr != Operator.none){
            TextView etext = (TextView)findViewById(R.id.ResultEdit);
            data2 = Double.parseDouble(etext.getText().toString());

            double result =0 ;
            if (optr == Operator.add){
                result = data1 + data2;
            }
            else if(optr == Operator.minus){
                result = data1 - data2;
            }
            else if(optr == Operator.multiply){
                result = data1 * data2;
            }
            else if(optr == Operator.divide){
                result = data1 / data2;
            }
            optr = Operator.none;
            data1 = result;
            if((result - (int) result)!=0){
                etext.setText(String.valueOf(result));
            }
            else{
                etext.setText(String.valueOf((int) result));
            }
        }
    }


}